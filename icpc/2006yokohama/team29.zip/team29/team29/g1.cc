#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>

using namespace std;

#define REP(i, n) for(int i = 0; i < (int)(n); i++)
#define FOR(it,c) for(__typeof((c).begin()) it = (c).begin(); it != (c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()

#define cin hogehoge


typedef complex<int> P;

int given[10] = {-1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000, -1000};
P polygon[10];
int nPoints;

const double PI = acos(0.0)*2;

double myatan2(int dy, int dx) {
  double th = atan2((double)dy, (double)dx);
  if (th < 0)
    th += 2*PI;
  return th;
}

vector<P> ddd[300+1];
int res;

int calc() {
  int s = 0;
  REP(i, nPoints) {
    int j = (i+1)%nPoints;
    s += polygon[i].real()*polygon[j].imag() - polygon[i].imag()*polygon[j].real();
  }
  return abs(s)/2;
}
#define EP 1e-3

void search(int depth, double angle) {
  /*
  REP(i, depth+1) {
    cout << polygon[i] << " - ";
  }
    cout << "angle = " << angle << endl;
    //*/
  if (depth == nPoints-1) {
    P last = polygon[depth];
    if (norm(last) == given[nPoints-1]*given[nPoints-1]) {
      double nextAngle = myatan2(-last.imag(), -last.real());
      if (nextAngle >= angle-EP) {
	res >?= calc();
      }
    }
  }
  else {
    for(int i = depth; i < nPoints; i++) {
      swap(given[i], given[depth]);
      {
	int use = given[depth];
	if (ddd[use].empty()) {
	  cout << use << " = ";
	  for(int dx = 0; dx <= use; dx++) {
	    for(int dy = 1; dx*dx+dy*dy <= use*use; dy++) {
	      if (dx*dx+dy*dy == use*use) {
		ddd[use].push_back(P(dx, dy));
		ddd[use].push_back(P(-dy, dx));
		ddd[use].push_back(P(-dx, -dy));
		ddd[use].push_back(P(dy, -dx));
		cout << dx << "^2 + " << dy << "^2 = ";
	      }
	    }
	  }
	  cout << endl;
	}
	REP(j, ddd[use].size()) {
	  int dx = ddd[use][j].real();
	  int dy = ddd[use][j].imag();
	  double nextAngle = myatan2(dy, dx);
	  if (nextAngle >= angle-EP && nextAngle < angle+PI-EP) {
	    polygon[depth+1] = polygon[depth] + P(dx, dy);
	    search(depth+1, nextAngle);
	  }
	  else if (dy == 0 && dx > 0) {
	    nextAngle = 2*PI;
	    polygon[depth+1] = polygon[depth] + P(dx, dy);
	    search(depth+1, nextAngle);
	  }
	}
      }
      swap(given[i], given[depth]);
    }
  }
}


int main() {

  ifstream fin("G.txt");

  while(fin >> nPoints && nPoints > 0) {
    REP(i, nPoints)
      fin >> given[i];
    res = -1;
    polygon[0] = P(0, 0);
    polygon[1] = P(given[0], 0);
    search(1, 0.0);
    if (res == 0)
      res = -1;
    printf("%d\n", res);
  }

  return 0;
}
