#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>

using namespace std;

#define REP(i, n) for(int i = 0; i < (int)(n); i++)
#define FOR(it,c) for(__typeof((c).begin()) it = (c).begin(); it != (c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()

#define cin hogehoge

typedef complex<double> P;

#define EP 1.0e-8
inline int SGN(double a) {
  return (abs(a)< EP ? 0 : a > 0 ? 1 : -1);
}
#define EQ(a,b) (SGN((a)-(b)) == 0)
#define NE(a,b) (SGN((a)-(b)) != 0)
#define LE(a,b) (SGN((a)-(b)) <= 0)
#define LT(a,b) (SGN((a)-(b)) < 0)
#define GE(a,b) (SGN((a)-(b)) >= 0)
#define GT(a,b) (SGN((a)-(b)) > 0)

struct L {
  P pos, dir;
};

inline double inp(const P& a, const P& b) {
  return (conj(a)*b).real();
}
inline double outp(const P& a, const P& b) {
  return (conj(a)*b).imag();
}
inline P proj(const P& p, const P& b) {
  return b*inp(p,b)/norm(b);
}

inline P perf(const L& l, const P& p) {
  L m = {l.pos-p, l.dir};
  return (p + (m.pos - proj(m.pos, m.dir)));
}
inline int ccw(const P& p, const P& r, const P& s) {
  P a(r-p), b(s-p);
  int sgn = SGN(outp(a, b));
  if (sgn != 0)
    return sgn;
  if (LT(a.real()*b.real(), 0) || LT(a.imag()*b.imag(), 0))
    return -1;
  if (LT(norm(a), norm(b)))
    return 1;
  return 0;
}
double lp_distance(const L& l, const P& p) {
  return abs(perf(l, p) - p);
}
double lp_signed_distance(const L& l, const P& p) {
  double d = lp_distance(l, p);
  if (ccw(l.pos, l.pos+l.dir, p) < 0)
    return -d;
  return d;
}


P line_cross(const L& l, const L& m) {
  double num = outp(m.dir, m.pos-l.pos);
  double denom = outp(m.dir, l.dir);
  if (abs(denom) < EP)
    return P(0, 0); // tofix
  return P(l.pos+l.dir*num/denom);
}



int n;
vector<P> polygon;

bool solve() {

  for(int i = 0; i < n; i++) {
    for(int j = i+1; j < n; j++) {
      L line1 = {polygon[i], polygon[(i+1)%n]-polygon[i]};
      L line2 = {polygon[j], polygon[(j+1)%n]-polygon[j]};
      P cross = line_cross(line1, line2);
      bool ok = true;
      REP(k, n) {
	L line0 = {polygon[k], polygon[(k+1)%n]-polygon[k]};
	double sd = lp_signed_distance(line0, cross);
	if (sd < 0-EP)
	  ok = false;
      }
      if (ok) {
	return true;
      }
    }
  }
  return false;
}

int main() {

  ifstream fin("B.txt");

  while(fin >> n && n > 0) {

    polygon.resize(n);
    REP(i, n) {
      double x, y;
      fin >> x >> y;
      polygon[i] = P(x, y);
    }

    bool result = solve();

    if (result)
      cout << 1 << endl;
    else
      cout << 0 << endl;

  }

  return 0;
}
