#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>

using namespace std;

#define REP(i, n) for(int i = 0; i < (int)(n); i++)
#define FOR(it,c) for(__typeof((c).begin()) it = (c).begin(); it != (c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()

#define cin hogehoge

#define N 1000
int res[N+1];

int limit;
int has[20];

void search(int depth, int n) {
  /*
  printf("%d,%d: ", depth, limit);
  REP(i, n)
    printf("%d ", has[i]);
  printf("\n");
  */
  if (depth == limit) {
    res[has[n-1]] <?= depth;
  }
  else {
    REP(i, n) {
      for(int j = i; j < n; j++) {
	int a = has[i];
	int b = has[j];
	if (a < b)
	  swap(a, b);
	{
	  int c = a+b;
	  if (count(has, has+n, c) == 0) {
	    has[n] = c;
	    search(depth+1, n+1);
	  }
	}
	{
	  int c = a-b;
	  if (c > 0) {
	    if (count(has, has+n, c) == 0) {
	      has[n] = c;
	      search(depth+1, n+1);
	    }
	  }
	}
      }
    }
  }
}

int main() {

  ifstream fin("F.txt");

  REP(i, N+1)
    res[i] = 100;

  // search
  has[0] = 1;
  limit = 0;
  for(;;) {
    //printf("depth=%d remain=%d\n", limit, count(res+1, res+N+1, 100));
    search(0, 1);
    printf("depth=%d: ", limit);
    REP(i, N+1) {
      if (res[i] == limit)
	printf("%d ", i);
    }
    printf("\n");
    limit++;
    if (count(res+1, res+N+1, 100) == 0)
      break;
  }

  return 0;
}
