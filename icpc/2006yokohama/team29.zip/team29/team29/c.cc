#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>

using namespace std;

#define REP(i, n) for(int i = 0; i < (int)(n); i++)
#define FOR(it,c) for(__typeof((c).begin()) it = (c).begin(); it != (c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()

#define cin hogehoge

struct Cell {
  int top, front, right;
};

struct State {
  Cell cells[9];
  int empty;
};

enum Color {
  White, Blue, Red
};

// 012
// 345
// 678

void print(State& s) {
      REP(i, 3) {
	REP(j, 3) {
	  int id = i*3 + j;
	  int color = s.cells[id].top;
	  if (id == s.empty) {
	    printf(".");
	  }
	  else {
	    printf("%c", "WBR"[color]);
	  }
	}
	printf("\n");
      }
}

int celltoInt(const Cell& c) {
  if (c.top == White)
    return (c.front == Blue ? 0 : 1);
  if (c.top == Blue)
    return (c.front == Red ? 2 : 3);
  if (c.top == Red)
    return (c.front == White ? 4 : 5);
  assert(false);
  return -1;
}

Cell cellfromInt(int repr) {
  Cell c;
  switch(repr) {
  case 0:
    c.top = White;
    c.front = Blue;
    c.right = Red;
    break;
  case 1:
    c.top = White;
    c.front = Red;
    c.right = Blue;
    break;
  case 2:
    c.top = Blue;
    c.front = Red;
    c.right = White;
    break;
  case 3:
    c.top = Blue;
    c.front = White;
    c.right = Red;
    break;
  case 4:
    c.top = Red;
    c.front = White;
    c.right = Blue;
    break;
  case 5:
    c.top = Red;
    c.front = Blue;
    c.right = White;
    break;
  }
  return c;
}

int toInt(const State& s) {
  int repr = 0;
  REP(i, 9) {
    if (i == s.empty)
      repr = repr * 6;
    else
      repr = repr * 6 + celltoInt(s.cells[i]);
  }
  repr = repr*9 + s.empty;
  return repr;
}

State fromInt(int repr) {
  State s;
  s.empty = repr%9;
  repr /= 9;
  for(int i = 8; i >= 0; i--) {
    s.cells[i] = cellfromInt(repr%6);
    repr /= 6;
  }
  return s;
}

void rollUp(Cell& c) {
  swap(c.top, c.front);
}
void rollDown(Cell& c) {
  swap(c.top, c.front);
}
void rollLeft(Cell& c) {
  swap(c.top, c.right);
}
void rollRight(Cell& c) {
  swap(c.top, c.right);
}

bool moveUp(State& t, const State& s) {
  if (s.empty < 3)
    return false;
  t = s;
  t.cells[t.empty] = t.cells[t.empty-3];
  rollUp(t.cells[t.empty]);
  t.empty -= 3;
  return true;
}
bool moveDown(State& t, const State& s) {
  if (s.empty >= 6)
    return false;
  t = s;
  t.cells[t.empty] = t.cells[t.empty+3];
  rollDown(t.cells[t.empty]);
  t.empty += 3;
  return true;
}
bool moveLeft(State& t, const State& s) {
  if (s.empty%3 == 0)
    return false;
  t = s;
  t.cells[t.empty] = t.cells[t.empty-1];
  rollLeft(t.cells[t.empty]);
  t.empty--;
  return true;
}
bool moveRight(State& t, const State& s) {
  if (s.empty%3 == 2)
    return false;
  t = s;
  t.cells[t.empty] = t.cells[t.empty+1];
  rollRight(t.cells[t.empty]);
  t.empty++;
  return true;
}

#define STATES (6*6*6*6*6*6*6*6*6*9)
#define INF (10000)

int steps[STATES];

void solve(State init_state, State end_state) {

  queue<int> q;
  q.push(toInt(init_state));

  REP(i, STATES)
    steps[i] = INF;
  steps[toInt(init_state)] = 0;

  while(!q.empty()) {

    int state_int = q.front();
    q.pop();

    if (steps[state_int] > 30)
      break;


    State s = fromInt(state_int);

    if (0){
      printf("%dsteps: %d\n", steps[state_int], state_int);
      print(s);
      char s[64];
      fgets(s, sizeof(s), stdin);
    }

      State t;
      if (moveLeft(t, s)) {
	if(0) {
	  print(t);
	  char s[64];
	  fgets(s, sizeof(s), stdin);
	}
	int new_state = toInt(t);
	if (steps[new_state] == INF) {
	  steps[new_state] = steps[state_int] + 1;
	  q.push(new_state);
	}
      }
      if (moveRight(t, s)) {
	if (0) {
	  print(t);
	  char s[64];
	  fgets(s, sizeof(s), stdin);
	}
	int new_state = toInt(t);
	if (steps[new_state] == INF) {
	  steps[new_state] = steps[state_int] + 1;
	  q.push(new_state);
	}
      }
      if (moveUp(t, s)) {
	if (0) {
	  print(t);
	  char s[64];
	  fgets(s, sizeof(s), stdin);
	}
	int new_state = toInt(t);
	if (steps[new_state] == INF) {
	  steps[new_state] = steps[state_int] + 1;
	  q.push(new_state);
	}
      }
      if (moveDown(t, s)) {
	if(0){
	  print(t);
	  char s[64];
	  fgets(s, sizeof(s), stdin);
	}
	int new_state = toInt(t);
	if (steps[new_state] == INF) {
	  steps[new_state] = steps[state_int] + 1;
	  q.push(new_state);
	}
      }

  }

  int res = INF;
  REP(i, STATES) {
    if (steps[i]  != INF) {
      State t = fromInt(i);
      bool match = true;
      if (end_state.empty != t.empty)
	match =false;
      REP(j, 9)
	if (t.cells[j].top != end_state.cells[j].top && j != t.empty)
	  match = false;
      if (match)
	res <?= steps[i];
    }
  }

  if (res <= 30)
    cout << res << endl;
  else
    cout << -1 << endl;
}
int main() {

  ifstream fin("C.txt");

  int x, y;
  while(fin >> x >> y && !(x == 0 && y == 0)) {
    int empty = x-1 + (y-1)*3;
    State init_state;
    init_state.empty = empty;//first_empty;
    REP(i, 9)
      init_state.cells[i] = cellfromInt(1);

    State end_state;
    REP(i, 9) {
      char c;
      fin >> c;
      switch(c) {
      case 'W':
	end_state.cells[i].top = White;
	break;
      case 'B':
	end_state.cells[i].top = Blue;
	break;
      case 'R':
	end_state.cells[i].top = Red;
	break;
      case 'E':
	end_state.empty = i;
	break;
      }
    }

    solve(init_state, end_state);
  }


}



