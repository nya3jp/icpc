#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>

using namespace std;

#define REP(i, n) for(int i = 0; i < (int)(n); i++)
#define FOR(it,c) for(__typeof((c).begin()) it = (c).begin(); it != (c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()

#define cin hogehoge

#define N 1000
#define INF 0x1fffffff

int main() {

  ifstream fin("F.txt");

  int res[N+1];
  REP(i, N+1)
    res[i] = INF;
  res[1] = 0;

  bool changed;
  do {
    changed = false;
    for(int i = 1; i <= N; i++) {
      for(int j = i; i+j <= N; j++) {
	int k = i+j;
	if (res[k] > res[i]+res[j]+1) {
	  changed = true;
	  res[k] = res[i]+res[j]+1;
	}
      }
      for(int j = 1; i-j >= 1; j++) {
	int k = i-j;
	if (res[k] > res[i]+res[j]+1) {
	  changed = true;
	  res[k] = res[i]+res[j]+1;
	}
      }
    }
  } while(changed);

  int given;
  while(fin >> given && given > 0) {
    cout << res[given] << endl;
  }

  return 0;
}
