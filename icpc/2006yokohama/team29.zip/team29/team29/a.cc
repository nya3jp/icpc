#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>

using namespace std;

#define REP(i, n) for(int i = 0; i < (int)(n); i++)
#define FOR(it,c) for(__typeof((c).begin()) it = (c).begin(); it != (c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()

#define cin hogehoge

struct P {
  double x, y, z;
};

double inp(const P& a, const P& b) {
  return a.x*b.x + a.y*b.y + a.z*b.z;
}

void normalize(P& p) {
  double n = sqrt(inp(p, p));
  p.x /= n;
  p.y /= n;
  p.z /= n;
}

int main() {

  ifstream fin("A.txt");

  for(;;) {
    int nStars;
    fin >> nStars;

    if (nStars == 0)
      break;

    // input
    vector<P> stars(nStars);
    REP(i, nStars) {
      P& star = stars[i];
      fin >> star.x >> star.y >> star.z;
      normalize(star);
    }

    int nScopes;
    fin >> nScopes;

    vector<P> scopes(nScopes);
    vector<double> angles(nScopes);
    REP(i, nScopes) {
      P& scope = scopes[i];
      fin >> scope.x >> scope.y >> scope.z;
      fin >> angles[i];
      normalize(scope);
    }

    // check
    vector<bool> seen(nStars, false);
    REP(iScope, nScopes) {
      P scope = scopes[iScope];
      double range = angles[iScope];
      REP(iStar, nStars) {
	P star = stars[iStar];
	double theta = acos(inp(scope, star));
	if (theta < range)
	  seen[iStar] = true;
      }
    }

    /*
    REP(i, nStars)
      if (seen[i])
	cout << i << ' ';
    cout << ": ";
    */

    cout << count(ALLOF(seen), true) << endl;

  }

  return 0;
}
