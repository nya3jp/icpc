#!/bin/sh
cd /usr/pc2
./pc2team
