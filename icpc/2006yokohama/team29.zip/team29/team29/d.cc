#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>
#include <functional>
#include <utility>
#include <numeric>
#include <complex>
#include <cstdio>
#include <cmath>
#include <cctype>
#include <cassert>

using namespace std;

#define REP(i, n) for(int i = 0; i < (int)(n); i++)
#define FOR(it,c) for(__typeof((c).begin()) it = (c).begin(); it != (c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()

#define cin hogehoge

#define N 1120
#define K 14
#define PRIMES 187

//vector<int> primes;
int primes[PRIMES];
bool isprime[N+1];
int nPrimes;

int dp[N+1][K+1][PRIMES+1];

int main() {

  REP(i, N+1)
    isprime[i] = true;
  isprime[0] = isprime[1] = false;
  nPrimes = 0;
  for(int i = 2; i <= N; i++) {
    if (isprime[i]) {
      //primes.push_back(i);
      primes[nPrimes++] = i;
      for(int j = i*i; j <= N; j += i)
	isprime[j] = false;
    }
  }

  ifstream fin("D.txt");

  //  int nPrimes = primes.size();

  //cout << nPrimes << endl;

  int given_n, given_k;
  while(fin >> given_n >> given_k && !(given_n == 0 && given_k == 0)) {

    // init
    for(int n = 0; n <= given_n; n++) {
      for(int k = 0; k <= given_k; k++) {
	for(int used = 0; used <= nPrimes; used++) {
	  dp[n][k][used] = (n == 0 && k == 0 && used == 0 ? 1 : 0);
	}
      }
    }

    for(int n = 0; n <= given_n; n++) {
      for(int k = 0; k <= given_k; k++) {
	for(int used = 0; used <= nPrimes; used++) {
	  for(int prime_i = used; prime_i < nPrimes; prime_i++) {
	    int p = primes[prime_i];
	    if (n+p > given_n)
	      break;
	    if (k+1 > given_k)
	      break;
	    if (prime_i+1 > nPrimes)
	      break;
	    dp[n+p][k+1][prime_i+1] += dp[n][k][used];
	  }
	}
      }
    }

    int* ans = dp[given_n][given_k];
    cout << accumulate(ans, ans+nPrimes+1, (int)0) << endl;

  }

  return 0;
}
