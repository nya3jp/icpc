package codebear.user;
import codebear.system.*;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CodeBearFrame f = new CodeBearFrame(args);
		f.setResizable(false);
	}

}
