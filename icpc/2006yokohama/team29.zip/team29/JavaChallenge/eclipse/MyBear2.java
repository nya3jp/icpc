package codebear.user;

import java.util.*;
import java.awt.*;

import codebear.system.*;

public class MyBear2 extends MyBearBase implements IMyBear {
	int direction = 0;

	int manhattanLength(Salmon s) {
		int r;
		Point p1 = getCenterPosition(), p2 = s.getCenterPosition();
		r = Math.abs(p1.x - p2.x) + Math.abs(p1.y - p2.y);
		return r;
	}

	public void register() {
		// TODO Write your own name
		setTeamName("Sample Bear");
		setOrganizationName("KEIO Univ.");
	}

	void sample_think(ArrayList<Salmon> salmons, ArrayList<Block> blocks) {
		// Sample: simple and buggy AI.
		Iterator<Salmon> sit = salmons.iterator();
		Salmon mostNear = null;
		int tmp = Integer.MAX_VALUE;
		while (sit.hasNext()) {
			Salmon s = sit.next();
			int dist = manhattanLength(s);
			if (dist < tmp) {
				mostNear = s;
				tmp = dist;
			}
		}

		Point p1 = getCenterPosition(), p2 = mostNear.getCenterPosition();
		
		switch (direction) {
		case 1:
			if (Math.abs((p1.x-15)-p2.x) < 10 && Math.abs(p1.y-p2.y) < 10) {
				attackSalmon();
			}
			break;
		case 2:
			if (Math.abs((p1.x+15)-p2.x) < 10 && Math.abs(p1.y-p2.y) < 10) {
				attackSalmon();
			}
			break;
		case 3:
			if (Math.abs(p1.x-p2.x) < 10 && Math.abs((p1.y+15)-p2.y) < 10) {
				attackSalmon();
			}
			break;
		case 4:
			if (Math.abs(p1.x-p2.x) < 10 && Math.abs((p1.y-15)-p2.y) < 10) {
				attackSalmon();
			}
			break;
		}

		if (p1.x > p2.x + 5) {
			moveLeft();
			direction = 1;
		} else if (p1.x < p2.x - 5) {
			moveRight();
			direction = 2;
		} else if (p1.y < p2.y + 5) {
			moveDown();
			direction = 3;
		} else if (p1.y > p2.y - 5) {
			moveUp();
			direction = 4;
		}
	}

	public void think(ArrayList<Salmon> salmons, ArrayList<Block> blocks) {
		// TODO Write your own code
		sample_think(salmons, blocks);
	}

}
