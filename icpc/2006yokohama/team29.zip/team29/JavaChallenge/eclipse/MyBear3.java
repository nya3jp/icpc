package codebear.user;

import java.util.*;
import java.awt.*;

import codebear.system.*;

public class MyBear1 extends MyBearBase implements IMyBear {

    static class SalmonInfo {
	Point position;
	int direction;
    }

    ArrayList<Salmon> currentSalmons = new ArrayList<Salmon>();
    ArrayList<SalmonInfo> currentSalmonInfos = new ArrayList<SalmonInfo>();
    boolean inited = false;

    public void init(ArrayList<Salmon> salmons) {
	int nSalmons = salmons.size();
	for(int i = 0; i < nSalmons; i++)
	    currentSalmons.add(salmons.get(i));
	for(int i = 0; i < nSalmons; i++) {
	    SalmonInfo salmonInfo = new SalmonInfo();
	    salmonInfo.direction = 0;
	    salmonInfo.position = salmons.get(i).getCenterPosition();
	    currentSalmonInfos.add(salmonInfo);
	}
    }

    public void register(){
	setTeamName("CLAGGANO");
	setOrganizationName("www.claggano.gunma.go.jp");
    }
	
    public void think(ArrayList<Salmon> salmons, ArrayList<Block> blocks) {
	if (!inited) {
	    inited = true;
	    init(salmons);
	}
	manageSalmons(salmons);
	decideMove(salmons, blocks);
    }

    void decideMove(ArrayList<Salmon> salmons, ArrayList<Block> blocks) {
	for(int i = 0; i < salmons.size(); i++) {
	    SalmonInfo info = currentSalmonInfos.get(i);
	    System.out.printf("Salmon%d: (%d,%d) dir=%d\n", i, info.position.x, info.position.y, info.direction);
	}
	System.out.println();
    }

    int manhattanNorm(Point a, Point b) {
	if (a == null || b == null)
	    return 0x7fffffff;
	return (Math.abs(a.x-b.x) + Math.abs(a.y-b.y));
    }
	
    void manageSalmons(ArrayList<Salmon> nextSalmons) {
	int n = currentSalmons.size();
	ArrayList<Integer> mapping = new ArrayList<Integer>();
	for(int i = 0; i < n; i++)
	    mapping.add(-1);
	for(int iCurrent = 0; iCurrent < n; iCurrent++) {
	    int res = -1;
	    int best = 100000000;
	    for(int iNext = 0; iNext < n; iNext++) {
		int dist = manhattanNorm(currentSalmons.get(iCurrent).getPosition(), nextSalmons.get(iNext).getPosition());
		if (dist < best) {
		    res = iNext;
		    best = dist;
		}
		if (currentSalmons.get(iCurrent) == nextSalmons.get(iNext))
		    res = iNext;
	    }
	    mapping.set(iCurrent, res);
	}

	ArrayList<SalmonInfo> nextSalmonInfos = new ArrayList<SalmonInfo>();
	for(int i = 0; i < n; i++)
	    nextSalmonInfos.add(null);

	for(int i = 0; i < n; i++) {
	    if (mapping.get(i) >= 0) {
		int j = mapping.get(i);
		Point before = currentSalmonInfos.get(i).position;
		Point after = nextSalmons.get(j).getPosition();
		int dx = after.x - before.x;
		int dy = after.y - before.y;
		System.out.printf("d=(%d,%d)\n", dx, dy);
		nextSalmonInfos.set(j, currentSalmonInfos.get(i));
		nextSalmonInfos.get(j).position = nextSalmons.get(j).getCenterPosition();
		int direction;
		if (dx == 0 && dy == 0) {
		    direction = -1;
		}
		else if (Math.abs(dx) > Math.abs(dy)) {
		    if (dx > 0)
			direction = 0;
		    else
			direction = 2;
		}
		else {
		    if (dy > 0)
			direction = 1;
		    else
			direction = 3;
		}
		nextSalmonInfos.get(j).direction = direction;
	    }
	}
	for(int i = 0; i < n; i++) {
	    if (nextSalmonInfos.get(i) == null) {
		// new salmon
		SalmonInfo newInfo = new SalmonInfo();
		newInfo.position = nextSalmons.get(i).getPosition();
		newInfo.direction = 0;
	    }
	}
    }
	

}
