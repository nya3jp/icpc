package codebear.user;

import java.util.*;

import codebear.system.*;

public class MyBear1 extends MyBearBase implements IMyBear {
	public void register(){
		setTeamName("Sample");
		setOrganizationName("sample.org");
	}
	
	public void think(ArrayList<Salmon> salmons, ArrayList<Block> blocks) {
		// TODO  Write your own code
		sample_think(blocks);
	}
	
	int direction = 0;
	void sample_think(ArrayList<Block> blocks){
		//	Sample: Only up-down moving thinking with blocks
		Iterator<Block> blockIterator = blocks.iterator();
		while(blockIterator.hasNext()){
			Block b = blockIterator.next();
			if(this.hitTest(b)){
				direction = 1;
			}
		}
		if(getTop()<=0){direction = 0;}
		if(getBottom()>=480){direction = 1;}

		if(direction == 1){moveUp();}
		else moveDown();
	}

}
